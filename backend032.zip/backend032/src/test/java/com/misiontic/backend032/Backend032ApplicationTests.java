package com.misiontic.backend032;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Backend032ApplicationTests {

	@Test
	void contextLoads() {
	}

}
